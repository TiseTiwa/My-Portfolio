const express = require("express");
const router = express.Router();
const messageController = require("../controllers/messageControllers");

router.get("/messages/:sender/:receiver", messageController.getMessages);
router.post("/messages", messageController.createMessage);
router.patch("/messages/:id/read", messageController.markAsRead);
router.patch("/messages/:id/update", messageController.updateMessage);
router.delete("/messages/:id/delete", messageController.deleteMessage);

module.exports = router;

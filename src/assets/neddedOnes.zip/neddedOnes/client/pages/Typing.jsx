import React, { useEffect, useContext } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { MessageContext } from "../client/context/MessageContext";
import Arrow from "../images/chevron_left.png";
import Verified from "../images/Vector (1).png";
import phone from "../images/Icons.png";
import Booking from "../images/Image.png";
import star from "../images/star_half.png";
import { IoMdSend } from "react-icons/io";
import {
  MdOutlineFilePresent,
  MdOutlineCameraAlt,
  MdOutlineKeyboardVoice,
} from "react-icons/md";
import { BsThreeDotsVertical } from "react-icons/bs";

const Typing = () => {
  const {
    messages,
    input,
    setInput,
    editId,
    menuOpen,
    setMenuOpen,
    isKeyboardOpen,
    inputRef,
    messagesEndRef,
    currentUser,
    userMap,
    fetchMessages,
    sendMessage,
    deleteMessage,
    startEdit,
  } = useContext(MessageContext);

  const navigate = useNavigate();
  const { id } = useParams();
  const chatUser = userMap[id]?.name;
  const chatAvatar = userMap[id]?.avatar;

  useEffect(() => {
    if (!chatUser || !chatAvatar) {
      console.error("Invalid user ID, redirecting to /message");
      navigate("/message");
      return;
    }
    fetchMessages(chatUser);
  }, [chatUser, fetchMessages, navigate]);

  const handleSend = () => sendMessage(chatUser);

  if (!chatUser || !chatAvatar) {
    return null; // Render nothing until redirect
  }

  return (
    <div className="flex flex-col items-center bg-[#FBFBFB] pb-20 mt-[-20px]">
      <div className="w-[375px]">
        <div className="flex items-center p-4 justify-between h-[72px]">
          <img
            src={Arrow}
            className="w-[24px] h-[24px] mr-1"
            onClick={() => navigate("/message")}
            style={{ cursor: "pointer" }}
            alt="Back"
          />
          <div className="flex p-1 gap-3 mb-2 rounded-lg w-[343px]">
            <img
              src={chatAvatar}
              className="w-[30px] h-[30px] rounded-full object-cover mt-[10px]"
              alt={chatUser}
            />
            <div className="flex-1">
              <div className="flex justify-between items-center w-full">
                <div className="flex items-center gap-1">
                  <h1 className="font-bold text-[#2D2E2E] w-[106px] h-[24px] text-[16px] leading-[24px]">
                    {chatUser}
                  </h1>
                  <img src={Verified} className="w-4 h-4" alt="Verified" />
                </div>
              </div>
              <div className="flex items-start justify-between mt-1">
                <p className="text-[12px] leading-[16px] text-gray-600 max-w-[70%]">
                  Property Owner
                </p>
                <img
                  src={phone}
                  className="w-[30px] h-[30px] mt-[-18px] ml-auto mr-[-10px]"
                  alt="Phone"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="w-full max-w-[375px] px-4 mt-2 border-[#EDF1F5] p-4">
        <div className="flex items-start w-full h-[102px] border border-[#EDF1F5] rounded-lg ml-[-30px]">
          <img
            src={Booking}
            className="w-[82px] h-[102px] object-cover rounded-l-lg"
            alt="Booking"
          />
          <div className="flex-1 p-3 h-full flex flex-col justify-between">
            <div>
              <h3 className="font-bold text-[12px] leading-[16px] text-[#2D2E2E]">
                Villa Family Resort Dago Pakar
              </h3>
              <p className="text-[10px] text-[#A6A9AC] leading-[14px] mt-1">
                Dago Pakar, Bandung
              </p>
            </div>
            <div className="flex items-center gap-1.5">
              <img src={star} className="w-3 h-3" alt="star" />
              <p className="text-[10px] text-[#747677] leading-[14px]">
                4.8 (21 Reviews)
              </p>
            </div>
            <p className="text-[14px] font-bold leading-[20px] text-[#2D2E2E]">
              $152
              <span className="text-[10px] text-[#A6A9AC] ml-0.5">/night</span>
            </p>
          </div>
        </div>
      </div>
      <div className="w-full max-w-[375px] px-4 mt-4 space-y-4">
        {messages.map((msg, index) => {
          const isMe = msg.sender === currentUser;
          const isDefault = msg.isDefault;
          const bubbleClasses = isDefault
            ? "p-3 w-[242px] h-auto flex flex-col justify-start break-words overflow-visible"
            : "p-3 max-w-[242px] flex flex-col break-words";

          return (
            <div
              key={msg._id || index}
              className={`flex ${
                isMe ? "justify-end mr-[-32px]" : "justify-start ml-[-30px]"
              }`}
            >
              <div
                className={`relative ${
                  isMe
                    ? "bg-[#0167FF] text-white rounded-tl-[12px] rounded-tr-[12px] rounded-bl-[12px]"
                    : "bg-[#DCE0E4] text-black rounded-tl-[12px] rounded-tr-[12px] rounded-br-[12px]"
                } ${bubbleClasses}`}
              >
                {isMe && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setMenuOpen(
                        menuOpen === (msg._id || index)
                          ? null
                          : msg._id || index
                      );
                    }}
                    className="absolute top-2 right-2"
                  >
                    <BsThreeDotsVertical className="text-white" />
                  </button>
                )}
                <p
                  className={`${
                    isMe
                      ? "text-[13px] leading-[16px] pr-8 break-words"
                      : "text-[14px] leading-[20px] break-words"
                  }`}
                >
                  {msg.text}
                </p>
                <div
                  className={`flex ${
                    isDefault && index === 1 ? "justify-start" : "justify-end"
                  }`}
                >
                  <span
                    className={`text-[10px] ${
                      isMe ? "text-[#DCE0E4]" : "text-[#747677]"
                    }`}
                  >
                    {msg.time || "Just now"}
                    {isMe && msg.read && " · Read"}
                  </span>
                </div>
                {menuOpen === (msg._id || index) && (
                  <div className="absolute right-0 top-8 bg-white border border-gray-200 rounded-lg shadow-lg z-50 w-28">
                    <div className="py-1">
                      <button
                        className="w-full text-left px-4 py-2 text-sm text-blue-500 hover:bg-gray-100"
                        onClick={(e) => {
                          e.stopPropagation();
                          startEdit(
                            msg._id || index,
                            msg.text,
                            msg.canEditUntil
                          );
                        }}
                      >
                        Edit
                      </button>
                      <button
                        className="w-full text-left px-4 py-2 text-sm text-red-500 hover:bg-gray-100"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (msg.sender === currentUser) {
                            deleteMessage(msg._id || index);
                          }
                        }}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>
      <div className="fixed bottom-0 left-0 right-0 p-4 ml-[-15px]">
        <div className="max-w-[375px] mx-auto w-full px-4">
          {!isKeyboardOpen ? (
            <div className="flex items-center gap-[16px] w-full">
              <MdOutlineFilePresent className="ml-[10px] w-[34px] h-[34px]" />
              <input
                type="text"
                ref={inputRef}
                placeholder="Type message"
                className="w-[205px] border border-[#EDF1F5] rounded-xl px-4 py-2 focus:outline-none text-[16px] text-black bg-[#DCE0E4]"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
              />
              <MdOutlineCameraAlt className="ml-[15px] w-[34px] h-[34px]" />
              <MdOutlineKeyboardVoice className="mr-[-15px] w-[34px] h-[34px]" />
            </div>
          ) : (
            <div className="flex items-center gap-2 w-full">
              <input
                type="text"
                ref={inputRef}
                placeholder="Oh, Okay Thanks"
                className="flex-1 border border-[#EDF1F5] rounded-xl px-4 py-2 focus:outline-none text-[16px] text-black bg-[#DCE0E4] w-full"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
              />
              <IoMdSend
                className="bg-[#0167FF] text-white rounded-full p-2 transition-colors w-10 h-10 flex items-center justify-center"
                onClick={handleSend}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Typing;

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { MessageProvider } from "../client/context/MessageContext";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <MessageProvider>
    <App />
  </MessageProvider>
);

import { BrowserRouter, Routes, Route } from "react-router-dom";
import Typing from "./components/Typing";
import Message from "./components/Message";

const App = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/message" element={<Message />} />
      <Route path="/typing/:id" element={<Typing />} />
      <Route path="/" element={<Message />} />
    </Routes>
  </BrowserRouter>
);

export default App;
